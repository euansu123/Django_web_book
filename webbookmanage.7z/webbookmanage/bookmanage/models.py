from django.db import models

# Create your models here.
# 图书
class Book(models.Model):
    bid = models.AutoField(primary_key = True) # 自增
    title = models.CharField(max_length=32) #书名
    price = models.DecimalField(max_digits=8,decimal_places=2) # 设置为十进制格式，最大位数为8位数，小数点后两位
    pub_data = models.DateField() # 出版日期：时间格式为年-月-日
    # 多对一关联
    pub = models.ForeignKey(to='Publish', to_field='pid', on_delete=models.CASCADE)

    # 多对多关联
    auth = models.ManyToManyField(to='Auth')

class AuthInfo(models.Model):
    aid = models.AutoField(primary_key = True)
    addr = models.CharField(max_length=50)
    tel = models.CharField(max_length=11)
# 作者
class Auth(models.Model):
    nid = models.AutoField(primary_key = True)
    ananame = models.CharField(max_length=20)
    # 对应作者详情一对一关联
    info = models.OneToOneField(to='AuthInfo',to_field='aid',on_delete=models.CASCADE)

# 出版社
class Publish(models.Model):
    pid = models.AutoField(primary_key = True)
    pname = models.CharField(max_length=20)
    pemail = models.CharField(max_length=20)
