# Create your views here.
from django.shortcuts import render, redirect
from django.urls import reverse
from bookmanage.models import Auth, Publish, Book


def book_add(request):
    # 当前提交图书的信息
    if request.method=='POST':
        tit = request.POST.get('tit')
        pri = request.POST.get('pri')
        pub_dt = request.POST.get('pub_dt')
        # 获取多对一的出版社编号
        pubid = request.POST.get('pubid')
        auths = request.POST.getlist('auths') # 多个作者
        # 图书插入
        book_obj = Book.objects.create(title=tit, price=pri, pub_data=pub_dt, pub_id=pubid)
        # 多对多的作者：book_obj.auth.add(*[作者列表])
        book_obj.auth.add(*auths)
        # 使用重定向跳转到查询页面，防止重定向
        urlpath = reverse('database:show')
        return redirect(urlpath)

        # 插入图书信息
    # 如果使用get方式提交请求，获取相关出版社和作者信息，并加载图书界面
    publis = Publish.objects.all()
    authlis = Auth.objects.all()
    # book_obj = Book.objects.create(title=title,price=price,publishDate=pub_date,publish_id=publish_id)
    return render(request,'bookmanage/bookadd.html',locals())

def querybook(request):
    if request.method == 'POST':
        temp = request.POST.get('query')
        if temp=='':
            return render(request, 'bookmanage/querybook.html')
        books = []
        book_objs = Book.objects.filter(Q(auth__ananame__contains=temp)|Q(pub__pname__contains=temp)|Q(title__contains=temp))
        for obj in book_objs:
            # print(obj.title)
            dic = {}
            dic['title']=obj.title
            dic['price']=obj.price
            dic['pub_data']=obj.pub_data
            dic['pub__pname']=obj.pub.pname
            au = Auth.objects.filter(book__bid=obj.bid)
            print('bid',obj.bid)
            name = []
            for a in au:
                name.append(a.ananame)
                # dic['auth__ananame']=[a.ananame]
            books.append(dic)
            dic['auth__ananame'] = name
            # print(name)
        print(books)
        return render(request, 'bookmanage/returnbook.html',{'book_list':books})
    return render(request, 'bookmanage/querybook.html')

def show(request):
    book_list = Book.objects.all().order_by('price').values('bid','title','price','pub_data','auth__ananame','pub__pname')
    # book_list类型：QuerySet()
    # 如下所写内容是为了解决相同图书作者不同重复输出的问题
    books = []
    for b in book_list:
        # b在这里是一个具体的存储对象
        # 字典对象
        dic={}
        # 验证是否为一本书
        flag = False
        for k,v in b.items():
            # print(k,v)
            for book in books:
                # print(book)
                if k == 'auth__ananame' and dic.get('title',None) and book['title']  ==dic.get('title',None):
                    # print(f'相同作者{v}')
                    flag = True
                    book['auth__ananame'].append(v)
                    break
            if flag:
                break
            if k == 'auth__ananame':
                dic[k] = [v]
            else:
                dic[k] = v
        if flag == False:
            books.append(dic)
    # print(books)
    return render(request, 'bookmanage/show.html', {'book_list':books})

def delbook(request,bookid):
    Book.objects.filter(pk=bookid).delete()
    urlpath = reverse('database:show')
    return redirect(urlpath)

def editbook(request,bookid):
    publis = Publish.objects.all() # 所有的出版社信息
    authlis = Auth.objects.all() # 所有的作者信息
    book = Book.objects.filter(pk=bookid).first()
    auth = Auth.objects.filter(book__bid=bookid).first()
    print(f'编辑:{auth},pub:{book.pub.pid}')
    if request.method == 'POST':
        title = request.POST.get('title')
        price = request.POST.get('price')
        pub_data = request.POST.get('pub_data')
        # 获取多对一的出版社编号
        pubid = request.POST.get('pub_id')
        print(f'pubid:{pubid}')
        auths = request.POST.getlist('auths')  # 多个作者
        print(f'auths:{auths}')
        Book.objects.filter(pk=bookid).update(title=title, price=price, pub_data=pub_data,pub_id=pubid)
        book.auth.clear()
        book.auth.add(*auths)
        # 使用重定向跳转到查询页面，防止重定向
        urlpath = reverse('database:show')
        return redirect(urlpath)

    return render(request,'bookmanage/editbook.html',locals())
