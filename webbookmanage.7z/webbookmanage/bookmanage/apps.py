from django.apps import AppConfig


class BookmanageConfig(AppConfig):
    name = 'bookmanage'
